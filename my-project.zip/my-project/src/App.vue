<template>
  <div id="app">
    <div id="nav">
      |
      <!-- <router-link to="/">Home</router-link> |  -->
      <router-link to="/">HOME</router-link>|
      <!-- <router-link to="/api/devicetype"> Device Type</router-link>|  -->
      <!-- <router-link to="/api/overview/modeltype">modeltype</router-link>|
      <router-link to="/api/overview/modeldata"> modeldata</router-link>|
      <router-link to="/api/devicemodel"> devicemodel</router-link>| -->
    </div>
    <router-view />
  </div>
</template>


<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
